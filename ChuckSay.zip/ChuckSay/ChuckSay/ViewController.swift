//
//  ViewController.swift
//  ChuckSay
//
//  Created by Gravman on 8/26/19.
//  Copyright © 2019 Alexandr_P. All rights reserved.
//

import UIKit
import MessageUI

class ViewController: UIViewController {
    let mailController = MFMailComposeViewController()
    let messageController = MFMessageComposeViewController()
    
    @IBOutlet weak var textJoke: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func refreshBut(_ sender: Any) {
        let model = Model()
        textJoke.text = model.loadJoke()
    }
    
    @IBAction func messageAction(_ sender: Any) {
        messageController.messageComposeDelegate = self
        messageController.body = textJoke.text
    }
    
    
    @IBAction func mailAction(_ sender: Any) {
        mailController.setSubject("New Chuk`s joke")
        mailController.setMessageBody(textJoke.text!, isHTML: false)
        mailController.mailComposeDelegate = self
        self.present(mailController, animated: true, completion: nil)
    }
    
}
extension ViewController: MFMailComposeViewControllerDelegate {
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        mailController.dismiss(animated: true) {
            var mailText = ""
            switch result {
            case .cancelled: mailText = "Mail was canceled"
            case .saved: mailText = "Mail was saved"
            case .sent: mailText = "Mail was sent"
            case .failed: mailText = "Mail was failed"
            default: mailText = "Loading"
            }
            let alertC = UIAlertController(title: mailText, message: "", preferredStyle: .alert)
            alertC.addAction(UIAlertAction(title: "Ok", style: .default, handler: { _ in  }))
            self.present(alertC, animated: true, completion: nil)
            
        }
    }
}
extension ViewController: MFMessageComposeViewControllerDelegate {
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        messageController.dismiss(animated: true) {
            var messageText = ""
            switch result {
            case .cancelled: messageText = "Message was canceled"
            case .failed: messageText = "Message was failed"
            case .sent: messageText = "Message was sent"
            default: messageText = "Loading"
            }
            let alertCont = UIAlertController(title: messageText, message: "", preferredStyle: .actionSheet)
            alertCont.addAction(UIAlertAction(title: "Ok", style: .default, handler: { _ in  }))
            self.present(alertCont, animated: true, completion: nil)
        }
    }
}
