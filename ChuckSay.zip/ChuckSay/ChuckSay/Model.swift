//
//  Model.swift
//  ChuckSay
//
//  Created by Gravman on 8/26/19.
//  Copyright © 2019 Alexandr_P. All rights reserved.
//


import UIKit

class Model: NSObject {
    func loadJoke() -> String {
        var returnJoke: String = ""
        let easyUrl = URL(string: "https://api.icndb.com/jokes/random")
        let data = NSData(contentsOf: easyUrl!)
        
        do {
            let dict = try JSONSerialization.jsonObject(with: data! as Data, options: .allowFragments) as! NSDictionary
            
            if dict.object(forKey: "type") as! String == "success" {
                returnJoke = (dict.object(forKey: "value") as! NSDictionary).object(forKey: "joke") as! String
            } else {
                returnJoke = "Ошибка при получении Json"
            }
        } catch {
            returnJoke = "Ошибка при распаковке json: \(error)"
        }
    
        return returnJoke.replacingOccurrences(of: "&quot;", with: "\"")
    }
}
